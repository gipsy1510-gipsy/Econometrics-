# Estructura mínima de datos

Crea un `dataset.xlsx` con estas columnas y algunos registros de ejemplo:

| Country | year | lnGDP | INFL | UNMEP | lnCON | lnPOP |
|---------|------|-------|------|-------|-------|-------|
| A       | 2000 | 10.5  | 3.2  | 8.1   | 9.8   | 16.1  |
| A       | 2001 | 10.6  | 3.0  | 8.0   | 9.9   | 16.1  |
| B       | 2000 | 10.2  | 5.0  | 10.0  | 9.5   | 15.9  |
| B       | 2001 | 10.3  | 4.7  | 9.8   | 9.6   | 16.0  |

**No subas datos sensibles a GitHub.**
