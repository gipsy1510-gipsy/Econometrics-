# 01_panel_analysis.R
# Limpio y reproducible a partir de código de clase para modelos de panel en R.
# Modelos: Pooled OLS, Efectos Fijos (FE), Efectos Aleatorios (RE), Primeras Diferencias (FD).
# Incluye pruebas: Hausman, heterocedasticidad, autocorrelación, dependencia transversal y normalidad.
# Resultados y figuras se guardan en `output/`.

suppressPackageStartupMessages({
  library(plm)
  library(readxl)
  library(sandwich)
  library(lmtest)
  library(tseries)
  library(stargazer)
  library(dplyr)
  library(ggplot2)
})

# === Configuración ===
DATA_PATH <- file.path("data", "dataset.xlsx")   # Cambia el nombre si tu archivo es distinto
OUT_DIR   <- "output"
dir.create(OUT_DIR, showWarnings = FALSE, recursive = TRUE)

# === Carga de datos ===
if (!file.exists(DATA_PATH)) {
  stop(paste0("No se encontró '", DATA_PATH, "'. Coloca tu archivo en la carpeta data/."))
}
data <- readxl::read_excel(DATA_PATH)

# Chequeos básicos
expected <- c("Country","year","lnGDP","INFL","UNMEP","lnCON","lnPOP")
missing_cols <- setdiff(expected, names(data))
if (length(missing_cols) > 0) {
  stop(paste("Faltan columnas en el dataset:", paste(missing_cols, collapse = ", ")))
}

# Tipos
data <- data %>%
  mutate(
    Country = as.factor(Country),
    year = as.integer(year)     # mantener numérico; usaremos factor cuando sea necesario
  )

# Panel pdata.frame
panel.data <- pdata.frame(data, index = c("Country", "year"))
sink(file.path(OUT_DIR, "00_panel_structure.txt"))
cat("pdim(panel.data):\n")
print(pdim(panel.data))
cat("\n")
cat("pvar(panel.data):\n")
print(pvar(panel.data))
sink()

# Dummy temporal (cuando aplique, usar factor(year) en fórmulas)
panel.data$year_factor <- as.factor(panel.data$year)

# === Modelos ===
# Pooled OLS (sin dummies)
Pooled <- plm(lnGDP ~ INFL + UNMEP + lnCON + lnPOP,
              data = panel.data, model = "pooling")

# Pooled OLS con dummies por país y año
# Nota: En pooling, incluir Country y year_factor explícitamente introduce dummies de indicador.
Pooled2 <- plm(lnGDP ~ INFL + UNMEP + lnCON + lnPOP + Country + year_factor,
               data = panel.data, model = "pooling")

# Efectos Aleatorios (RE) con dummies de tiempo
Random <- plm(lnGDP ~ INFL + UNMEP + lnCON + lnPOP + year_factor,
              data = panel.data, model = "random")

# Efectos Fijos (FE) con dummies de tiempo
Fixed <- plm(lnGDP ~ INFL + UNMEP + lnCON + lnPOP + year_factor,
             data = panel.data, model = "within")

# Primeras Diferencias (FD)
FD <- plm(lnGDP ~ INFL + UNMEP + lnCON + lnPOP + year_factor,
          data = panel.data, model = "fd")

# === Resúmenes y tablas ===
# Guardar resúmenes
capture.output(summary(Pooled),  file = file.path(OUT_DIR, "01_summary_pooled.txt"))
capture.output(summary(Pooled2), file = file.path(OUT_DIR, "02_summary_pooled_dummies.txt"))
capture.output(summary(Random),  file = file.path(OUT_DIR, "03_summary_random.txt"))
capture.output(summary(Fixed),   file = file.path(OUT_DIR, "04_summary_fixed.txt"))
capture.output(summary(FD),      file = file.path(OUT_DIR, "05_summary_fd.txt"))

# Comparaciones con stargazer
stargazer(Pooled, Pooled2, type = "text",
          column.labels = c("OLS", "OLS (con dummies)"),
          keep.stat = c("n","rsq"),
          out = file.path(OUT_DIR, "10_compare_pooled_vs_pooled2.txt"))

stargazer(Fixed, Pooled2, type = "text",
          column.labels = c("FE", "OLS (con dummies)"),
          keep.stat = c("n","rsq"),
          out = file.path(OUT_DIR, "11_compare_fe_vs_pooled2.txt"))

# Presentación general
stargazer(Pooled, Random, Fixed, FD, type = "text",
          column.labels = c("OLS", "RE", "FE", "FD"),
          keep.stat = c("n","rsq"),
          out = file.path(OUT_DIR, "12_compare_all_models.txt"))

# === Elección de modelo: Test de Hausman FE vs RE ===
haus <- phtest(Fixed, Random)
capture.output(haus, file = file.path(OUT_DIR, "20_hausman_fe_vs_re.txt"))

# === Validación de supuestos (sobre RE por ejemplo) ===

# 1) Heterocedasticidad (Breusch-Pagan)
# Nota: bptest( ) sobre objetos plm utiliza el método adecuado vía 'plm'.
bp <- bptest(Random)
capture.output(bp, file = file.path(OUT_DIR, "21_bptest.txt"))

# 2) Autocorrelación serial (Breusch-Godfrey para panel)
# pbgtest es más adecuado para paneles que bgtest clásico
bg <- pbgtest(Random)
capture.output(bg, file = file.path(OUT_DIR, "22_pbgtest_autocorr.txt"))

# 3) Dependencia transversal (LM de Breusch-Pagan)
pcd_lm <- pcdtest(Random, test = "lm")
capture.output(pcd_lm, file = file.path(OUT_DIR, "23_pcdtest_lm.txt"))

# 4) Errores robustos (Arellano)
cov_arellano <- vcovHC(Random, method = "arellano")
ct_arellano  <- coeftest(Random, vcov = cov_arellano)
capture.output(ct_arellano, file = file.path(OUT_DIR, "24_coeftest_arellano.txt"))

# 5) Normalidad de residuos (gráficos + Jarque-Bera)
res_re <- residuals(Random)

# Histograma
png(file.path(OUT_DIR, "30_hist_residuos_random.png"), width = 1200, height = 900, res = 150)
hist(res_re, main = "Residuos (RE): Histograma", xlab = "Residuo", breaks = 30)
dev.off()

# QQ-plot con ggplot2
qq_df <- data.frame(res = res_re)
png(file.path(OUT_DIR, "31_qqplot_residuos_random.png"), width = 1200, height = 900, res = 150)
ggplot(qq_df, aes(sample = res)) +
  stat_qq() +
  stat_qq_line() +
  labs(title = "Residuos (RE): QQ-plot")
dev.off()

jb <- jarque.bera.test(res_re)
capture.output(jb, file = file.path(OUT_DIR, "32_jarque_bera.txt"))

# === Mensaje final en consola ===
cat("Listo. Revisa la carpeta 'output/' para tablas y figuras.\n")
