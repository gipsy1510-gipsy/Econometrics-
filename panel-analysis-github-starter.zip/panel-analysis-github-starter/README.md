# Panel Econometrics: GDP, Inflation, Unemployment (R + `plm`)

Este repositorio contiene un flujo reproducible para estimar modelos de datos de panel con `plm` en R (pooled OLS, efectos fijos, efectos aleatorios y primeras diferencias), junto con pruebas de diagnóstico (Hausman, heterocedasticidad, autocorrelación, dependencia transversal y normalidad) y exportación automática de resultados.

> **Nota:** Los datos reales **no** se incluyen. Coloca tu archivo en `data/` (ver instrucciones abajo) o utiliza el dataset de ejemplo.

## Estructura

```
.
├─ src/
│  └─ 01_panel_analysis.R       # Script principal limpio y comentado
├─ data/                         # Coloca aquí tu `dataset.xlsx` (no versionado)
├─ output/                       # Resultados y figuras (auto-generado)
├─ docs/                         # Espacio para apuntes / reportes
├─ .gitignore
├─ LICENSE
└─ README.md
```

## Requisitos

- R >= 4.2
- Paquetes: `plm`, `readxl`, `sandwich`, `lmtest`, `tseries`, `stargazer`, `dplyr`, `ggplot2`

Instala paquetes con:
```r
install.packages(c("plm","readxl","sandwich","lmtest","tseries","stargazer","dplyr","ggplot2"))
```

## Cómo reproducir

1. Coloca tu archivo de datos (por ejemplo, `dataset.xlsx`) en `data/` con **al menos** las columnas:
   - `Country` (factor o cadena), `year` (numérico o entero)
   - `lnGDP`, `INFL`, `UNMEP`, `lnCON`, `lnPOP`
2. Ejecuta el script principal:
   ```r
   source("src/01_panel_analysis.R")
   ```
3. Revisa la carpeta `output/` para:
   - Tablas `.txt` de los modelos
   - Resultados de tests
   - Gráficos de diagnósticos de residuos

## Variables esperadas

- `lnGDP`: log del PIB (dependiente)
- `INFL`: inflación
- `UNMEP`: desempleo
- `lnCON`: log del consumo
- `lnPOP`: log de población
- `Country`: identificador de país
- `year`: año (numérico; el script lo convierte en factor para dummies de tiempo donde corresponde)

## Notas de reproducibilidad

- Se evita `attach()` y `file.choose()` para mantener el código limpio y reproducible.
- Si deseas aislar dependencias, puedes usar `{renv}`:
  ```r
  install.packages("renv")
  renv::init()
  ```

## Licencia

MIT — ver `LICENSE`.
